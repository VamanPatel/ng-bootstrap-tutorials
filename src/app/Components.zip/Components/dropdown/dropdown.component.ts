import { Component, OnInit } from '@angular/core';
import { NgbDropdownConfig } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.scss'],
})
export class DropdownComponent implements OnInit {
  // constructor(config: NgbDropdownConfig) {
  //   config.placement = 'bottom-left';
  //   config.autoClose = false;
  // }

  ngOnInit(): void {}
}
